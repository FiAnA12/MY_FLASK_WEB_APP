from itertools import groupby
from operator import or_
from flask import Flask, render_template, flash, request
from flask_sqlalchemy import SQLAlchemy
from numpy import average
from sqlalchemy.sql import func, or_, and_
from flask_migrate import Migrate
from datetime import datetime
from flask_login import UserMixin, login_user, login_manager, login_required, logout_user, current_user
from forms import NamingForm, UserForm, SearchForm
import json

#got to number 3 to add project to git
#Review number 7 to add javascript search to table
#----------------------------------------------------------------------------------------------------------------------------------------
#Create a Flask Instance
#-----------------------------------------------------------------------------------------------------------------------------
app = Flask(__name__)

#------------------------------------------------------------------------------------------------------------------------------------
#Add database/connect to databases
#-----------------------------------------------------------------------------------------------------------------------------------
#app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///user.db'
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Alice548511@localhost/project'
app.config['SECRET_KEY'] = "mykeys"

#------------------------------------------------------------------------------------------------------------------------------------
#Initialize the database
#-----------------------------------------------------------------------------------------------------------------------------------
db = SQLAlchemy(app)

#-------------------------------------------------------------------------------------------------------------------
##Create classes as db.Models for database design/or connect models with existing tables for querying
#----------------------------------------------------------------------------------------------------------------------
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), nullable=False, unique=True)
    date_added = db.Column(db.DateTime, default=datetime.utcnow)
    #Create a String
    def __repr__(self):
        return '<Name %r>' % self.name

class Flight(db.Model):
    
    __tablename__ = 'Flight'

    flight_id = db.Column(db.Integer,primary_key=True)
    qrter= db.Column(db.Integer, nullable=False)
    mnth=db.Column(db.Integer, nullable=False)
    day_of_month=db.Column(db.Integer,nullable=False)
    day_of_week=db.Column(db.Integer,nullable=False)
    fl_date=db.Column(db.Date)
    mkt_unique_carrier=db.Column(db.String(15))
    Segment = db.relationship('Segment',backref='Flight',uselist=False)
    Delay = db.relationship('Delay',backref='Flight',uselist=False)
    Cause = db.relationship('Cause',backref='Flight',uselist=False)

def __repr__(self):
    return f"Flight('{self.flight_id}', '{self.qrter}', '{self.mnth}', '{self.day_of_month}', '{self.day_of_week}', '{self.fl_date}', '{self.mkt_unique_carrier}')"

class Segment(db.Model):
    __tablename__ = 'Segment'

    segment_id = db.Column(db.Integer,db.ForeignKey('Flight.flight_id'),primary_key=True)
    origin= db.Column(db.String(55), nullable=False)
    origin_city_name=db.Column(db.String(55), nullable=False)
    origin_state_abr=db.Column(db.String(55), nullable=False)
    dest=db.Column(db.String(55),nullable=False)
    dest_city_name=db.Column(db.String(55),nullable=False)
    dest_state_abr=db.Column(db.String(55),nullable=False)

def __repr__(self):
    return f"Flight('{self.segment_id}', '{self.origin}', '{self.origin_state_abr}', '{self.dest}', '{self.dest_city_name}', '{self.dest_state_abr}')"

    
class Delay(db.Model):
    __tablename__ = 'Delay'

    delay_id = db.Column(db.Integer,db.ForeignKey('Flight.flight_id'),primary_key=True)
    dep_time= db.Column(db.Integer, nullable=False)
    dep_delay=db.Column(db.Integer, nullable=False)
    cancelled=db.Column(db.Integer,nullable=False)

def __repr__(self):
    return f"Flight('{self.delay_id}', '{self.dep_time}', '{self.dep_delay}', '{self.cancelled}')"


class Cause(db.Model):
    __tablename__ = 'Cause'

    cause_id = db.Column(db.Integer,db.ForeignKey('Flight.flight_id'),primary_key=True)
    carrier_delay= db.Column(db.Integer)
    weather_delay=db.Column(db.Integer)
    nas_delay=db.Column(db.Integer)
    security_delay=db.Column(db.Integer)
    late_aircraft_delay=db.Column(db.Integer)
    

def __repr__(self):
    return f"Flight('{self.cause_id}', '{self.carrier_delay}', '{self.weather_delay}', '{self.nas_delay}', '{self.security_delay}', '{self.late_aircraft_delay}')"

#Attributes can also be designed in one big table representing the above relations
class Flightdelays(db.Model):
    __tablename__ = 'Flightdelays'

    flight_id = db.Column(db.Integer,primary_key=True)
    qrter= db.Column(db.Integer, nullable=False)
    mnth=db.Column(db.Integer, nullable=False)
    day_of_month=db.Column(db.Integer,nullable=False)
    day_of_week=db.Column(db.Integer,nullable=False)
    fl_date=db.Column(db.Date)
    mkt_unique_carrier=db.Column(db.String(15))
    origin= db.Column(db.String(55), nullable=False)
    origin_city=db.Column(db.String(55), nullable=False)
    origin_state_abr=db.Column(db.String(55), nullable=False)
    dest=db.Column(db.String(55),nullable=False)
    dest_city_name=db.Column(db.String(55),nullable=False)
    dest_state_abr=db.Column(db.String(55),nullable=False)
    dep_time= db.Column(db.Integer, nullable=False)
    dep_delay=db.Column(db.Integer, nullable=False)
    cancelled=db.Column(db.Integer,nullable=False)
    carrier_delay= db.Column(db.Integer)
    weather_delay=db.Column(db.Integer)
    nas_delay=db.Column(db.Integer)
    security_delay=db.Column(db.Integer)
    late_aircraft_delay=db.Column(db.Integer)

#-------------------------------------------------------------------------------------------------------------------
##app routes
#----------------------------------------------------------------------------------------------------------------------
#Create a route decorator for webapp
@app.route('/')
def index():
    return render_template("index.html")

#Route for registration
@app.route('/user/register', methods=['GET', 'POST'])
def add_user():
    name = None
    form =UserForm()
    if form.validate_on_submit():
        Users = User.query.filter_by(email=form.email.data).first()
        if Users is None:
            users = User(name=form.name.data, email=form.email.data)
            db.session.add(users)
            db.session.commit()
        name = form.name.data
        form.name.data = ''
        form.email.data = ''
        flash("You are successfully registered")
    our_users = User.query.order_by(User.date_added)
    return render_template("add_user.html", form=form, name=name, our_users=our_users)

#Update database record for current registered user
@app.route('/update/<int:id>', methods=['POST','GET'])
def update(id):
    form = UserForm()
    name_to_update = User.query.get_or_404(id)
    if request.method == "POST":
        name_to_update.name = request.form['name']
        name_to_update.email = request.form['email']
        try:
            db.session.commit()
            flash("User updated Successfully")
            return render_template("update.html", form=form, name_to_update=name_to_update, id = id)
        except:
            flash("Error! Issue detected")
            return render_template("update.html", form=form, name_to_update=name_to_update, id = id)
    else:
        return render_template("update.html", form=form, name_to_update = name_to_update,id = id)

#Delete a registered user
@app.route('/delete/<int:id>')
def delete(id):
    user_to_delete = User.query.get_or_404(id)
    name = None
    form =UserForm()
    try:
        db.session.delete(user_to_delete)
        db.session.commit()
        flash("User Deleted Successfully")

        our_users = User.query.order_by(User.date_added)
        return render_template("add_user.html", form=form, name=name, our_users=our_users)
    except:
        flash("Oops! There was a problem, Try again...")
        return render_template("add_user.html", form=form, name=name, our_users=our_users)

@app.route('/user')
def user():
    return render_template("user.html")

#Invalid URL,page not found
@app.errorhandler(404)
def page_not_found(e):
    return render_template("404.html"), 404

@app.errorhandler(500)
def page_not_found(e):
    return render_template("400.html"), 500

# Example form to add name
@app.route('/name', methods=['GET','POST'])
def name():
    name = None
    form = NamingForm()
    if form.validate_on_submit():
        name = form.name.data
        form.name.data = ''
        flash("Form Submitted Successfully")
    return render_template("name.html", name = name, form = form)

#Context processor to render the search inside the base.html because of includes/extends to other templates
@app.context_processor
def base():
    form = SearchForm()
    return dict(form=form)

#First search test route
@app.route('/search', methods=['GET', 'POST'])
def search():
    form =SearchForm()
    Flights = Flight.query
    if form.validate_on_submit():
        searched=form.searched.data
        Flights = Flights.filter(Flight.flight_id.like('%' + searched + '%'))
        Flights = Flights.order_by(Flight.fl_date).all()
        return render_template("search.html", form=form, searched=searched, Flights=Flights)

#Second search: submit input,query database based on input and return query result 
@app.route('/searcher', methods=['GET', 'POST'])
def searcher():
    form =SearchForm()
    if form.validate_on_submit():
        searched=form.searched.data
        if searched in["denver","Denver","Atlanta","Dallas","Washington","Des Moines"]:
            results = Flight.query\
                .join(Delay, Flight.flight_id==Delay.delay_id)\
                .join(Segment, Flight.flight_id==Segment.segment_id)\
                .with_entities(func.avg(Delay.dep_delay))\
                .add_columns(Flight.mkt_unique_carrier)\
                .filter(Flight.mkt_unique_carrier.in_(('AA','AS','B6','DL','F9','G4','NK','UA','WN')))\
                .filter(Delay.dep_delay >0)\
                .filter(Segment.origin_city_name.ilike('%' + searched + '%'))\
                .group_by(Flight.mkt_unique_carrier).all()
            return render_template("searcher.html", form=form, searched=searched, results=results)
        elif searched in ["TX","VA","CO"]:
            results = Flightdelays.query\
                .with_entities(func.avg(Flightdelays.dep_delay))\
                .add_columns(Flightdelays.mkt_unique_carrier)\
                .filter(Flightdelays.mkt_unique_carrier.in_(('AA','AS','B6','DL','F9','G4','NK','UA','WN')))\
                .filter(Flightdelays.origin_state_abr.like('%' + searched + '%'))\
                .filter(Flightdelays.dep_delay >0)\
                .group_by(Flightdelays.mkt_unique_carrier).all()
            carrier = []
            count = []
            for i in results:
                carrier.append(i[0])
                count.append(i[1])   
            return render_template("searcher.html", form=form, searched=searched, results=results)
        elif searched in ["AA","AS","B6", "DL","F9","G4","NK","UA","WN"]:
            results = Flightdelays.query\
                .with_entities(func.avg(Flightdelays.dep_delay))\
                .add_columns(Flightdelays.mkt_unique_carrier)\
                .filter(Flightdelays.mkt_unique_carrier.in_(('AA','AS','B6','DL','F9','G4','NK','UA','WN')))\
                .filter(Flightdelays.origin_state_abr.like('%' + searched + '%'))\
                .filter(Flightdelays.dep_delay >0)\
                .group_by(Flightdelays.mkt_unique_carrier).all()
            return render_template("searcher.html", form=form, searched=searched, results=results)
        else:
            return render_template("invalid_src.html")   
#Third search test: submit input,query database based on input and return result in a chart form      
@app.route('/testchart', methods=['GET', 'POST'])
def testchart():
    form =SearchForm()
    if form.validate_on_submit():
        searched=form.searched.data
        if searched in ["TX","VA","CO"]:
            results = Flightdelays.query\
                .with_entities(func.avg(Flightdelays.dep_delay))\
                .add_columns(Flightdelays.mkt_unique_carrier)\
                .filter(Flightdelays.mkt_unique_carrier.in_(('AA','AS','B6','DL','F9','G4','NK','UA','WN')))\
                .filter(Flightdelays.origin_state_abr.like('%' + searched + '%'))\
                .filter(Flightdelays.dep_delay >0)\
                .group_by(Flightdelays.mkt_unique_carrier).all()
            count = []
            carrier = []
            for dep_delay, mkt_unique_carrier in results:
                count.append(str(dep_delay))
                carrier.append(mkt_unique_carrier)   
            return render_template("testchart.html", form=form, searched=searched, count = json.dumps(count), carrier=json.dumps(carrier))

#Chart Route/functions to search input by city, state, airlines, airport
@app.route('/charts', methods=['GET', 'POST'])
def charts():
    form =SearchForm()
    if form.validate_on_submit():
        searched=form.searched.data
        if searched in["denver","Denver","Atlanta","Dallas","Washington","Des Moines"]:
            results = Flight.query\
                .join(Delay, Flight.flight_id==Delay.delay_id)\
                .join(Segment, Flight.flight_id==Segment.segment_id)\
                .with_entities(func.avg(Delay.dep_delay))\
                .add_columns(Flight.mkt_unique_carrier)\
                .filter(Flight.mkt_unique_carrier.in_(('AA','AS','B6','DL','F9','G4','NK','UA','WN')))\
                .filter(Delay.dep_delay >0)\
                .filter(Segment.origin_city_name.ilike('%' + searched + '%'))\
                .group_by(Flight.mkt_unique_carrier).all()
            return render_template("charts.html", form=form, searched=searched, results=results)
        elif searched in ["TX","VA","CO"]:
            results = Flightdelays.query\
                .with_entities(func.avg(Flightdelays.dep_delay))\
                .add_columns(Flightdelays.mkt_unique_carrier)\
                .filter(Flightdelays.mkt_unique_carrier.in_(('AA','AS','B6','DL','F9','G4','NK','UA','WN')))\
                .filter(Flightdelays.origin_state_abr.like('%' + searched + '%'))\
                .filter(Flightdelays.dep_delay >0)\
                .group_by(Flightdelays.mkt_unique_carrier).all()
            count = []
            carrier = []
            for dep_delay, mkt_unique_carrier in results:
                count.append(str(dep_delay))
                carrier.append(mkt_unique_carrier)   
            return render_template("testchart.html", form=form, searched=searched, count = json.dumps(count), carrier=json.dumps(carrier))
        elif searched in ["AA","AS","B6", "DL","F9","G4","NK","UA","WN"]:
            results = db.session.query(Flightdelays.mkt_unique_carrier,\
                (func.sum(Flightdelays.dep_delay)/func.sum(Flightdelays.dep_delay + Flightdelays.cancelled + \
                Flightdelays.carrier_delay + Flightdelays.weather_delay + Flightdelays.security_delay + Flightdelays.late_aircraft_delay)*100),\
                (func.sum(Flightdelays.cancelled)/func.sum(Flightdelays.dep_delay + Flightdelays.cancelled + \
                Flightdelays.carrier_delay + Flightdelays.weather_delay + Flightdelays.security_delay + Flightdelays.late_aircraft_delay)*100),\
                (func.sum(Flightdelays.carrier_delay)/func.sum(Flightdelays.dep_delay + Flightdelays.cancelled + \
                Flightdelays.carrier_delay + Flightdelays.weather_delay + Flightdelays.security_delay + Flightdelays.late_aircraft_delay)*100),\
                (func.sum(Flightdelays.weather_delay)/func.sum(Flightdelays.dep_delay + Flightdelays.cancelled + \
                Flightdelays.carrier_delay + Flightdelays.weather_delay + Flightdelays.security_delay + Flightdelays.late_aircraft_delay)*100),\
                (func.sum(Flightdelays.nas_delay)/func.sum(Flightdelays.dep_delay + Flightdelays.cancelled + \
                Flightdelays.carrier_delay + Flightdelays.weather_delay + Flightdelays.security_delay + Flightdelays.late_aircraft_delay)*100),\
                (func.sum(Flightdelays.security_delay)/func.sum(Flightdelays.dep_delay + Flightdelays.cancelled + \
                Flightdelays.carrier_delay + Flightdelays.weather_delay + Flightdelays.security_delay + Flightdelays.late_aircraft_delay)*100),\
                (func.sum(Flightdelays.late_aircraft_delay)/func.sum(Flightdelays.dep_delay + Flightdelays.cancelled + \
                Flightdelays.carrier_delay + Flightdelays.weather_delay + Flightdelays.security_delay + Flightdelays.late_aircraft_delay)*100))\
                .filter(Flightdelays.mkt_unique_carrier.like('%' + searched + '%'))\
                .group_by(Flightdelays.mkt_unique_carrier).all()
            return render_template("charts.html", form=form, searched=searched, results=results)
        elif searched in ["DAL","DCA","DEN","DTM","DCW","ECP","ELP","FLL","GEG","GRR"]:
            results = db.session.query(Flightdelays.day_of_week,\
                func.avg(Flightdelays.dep_delay)\
                    .filter(Flightdelays.day_of_week.in_(('1','2','3','4','5','6','7')))
                    .filter(Flightdelays.origin.like('%' + searched + '%'))\
                    .filter(Flightdelays.dep_delay > 0))
            return render_template("charts.html", form=form, searched=searched, results=results)
        else:
            return render_template("invalid_src.html")   

#SELECT mkt_unique_carrier, 
#sum(dep_delay)/sum(dep_delay+cancelled+carrier_delay+weather_delay+security_delay+late_aircraft_delay)*100, 
#sum(CANCELLED)/sum(dep_delay+cancelled+carrier_delay+weather_delay+security_delay+late_aircraft_delay)*100, 
#sum(carrier_delay)/sum(dep_delay+cancelled+carrier_delay+weather_delay+security_delay+late_aircraft_delay)*100, 
#sum(weather_delay)/sum(dep_delay+cancelled+carrier_delay+weather_delay+security_delay+late_aircraft_delay)*100, 
#sum(nas_delay)/sum(dep_delay+cancelled+carrier_delay+weather_delay+security_delay+late_aircraft_delay)*100, 
#sum(security_delay)/sum(dep_delay+cancelled+carrier_delay+weather_delay+security_delay+late_aircraft_delay)*100, 
#sum(late_aircraft_delay)/sum(dep_delay+cancelled+carrier_delay+weather_delay+security_delay+late_aircraft_delay)*100 
#from Flightdelays WHERE MKT_UNIQUE_CARRIER = "AA" GROUP BY mkt_unique_carrier')
#---------------------------------------------------------------------------------------------------------------------------------------
#Testing bunch of code snippets, for SQLAlchemy use
#---------------------------------------------------------------------------------------------------------------------------------------

#elif form.searched.data == 
#(func.avg(Delay.dep_delay)).label("average"))\
#results = db.session.query(Flight, Delay, Segment).\
#select_from(Flight).join(Delay).join(Segment).all()
#results = db.session.query(Flight,Delay).\
#join(Flight, Delay, Segment).filter(and_(or_(Flight.mkt_unique_carrier=="WN"), Flight.mkt_unique_carrier=="UA"), Delay.dep_delay>0, Segment.origin_city_name.\
#LIKE('%' + searched + '%')).group_by(Flight.mkt_unique_carrier).all())
#return render_template("searcher.html", form=form, searched=searched, results=results)
#results = db.session.query(Flight.mkt_unique_carrier, (func.avg(Delay.dep_delay))\
#.join(Delay, Flight.flight_id==Delay.delay_id)\
#.join(Segment, Flight.flight_id==Segment.segment_id)\
#.filter(or_(Flight.mkt_unique_carrier=="WN"), Flight.mkt_unique_carrier=="UA")\
#.filter(Delay.dep_delay>0)\
#.filter(Segment.origin_city_name.like('%' + searched + '%')\
#.group_by(Flight.flight_id).all()))
#return render_template("searcher.html", form=form, searched=searched, results=results)
#results=Segment.query.filter(Segment.origin_city_name.like('%' + searched + '%'))
#results = Segment.query.order_by(Segment.origin_city_name).all()
#.join(Delay).join(Flight).\
#filter((or_(Flight.mkt_unique_carrier=="WN"), Flight.mkt_unique_carrier=="UA")).\
#filter(Delay.dep_delay>0).\
#filter(Segment.origin_city_name.like('%' + searched + '%').group_by(Flight.mkt_unique_carrier).all()))
#session = db.session
#q1 = session.query(Delay.delay_id, func.avg(Delay.dep_delay).label("average")).group_by(Flight.flight_id).subquery("sub1")
#q2 = session.query(Segment.segment_id, Segment.origin_city_name.like('%' + searched + '%')).group_by(Flight.flight_id).subquery("sub2")
#results = session.query(Flight, q1.c.average, q2.c).outerjoin(q1, q1.c.flight_id == Flight.flight_id).outerjoin(q2, q2.c.flight_id == Flight.flight_id)
#return render_template("searcher.html", form=form, searched=searched, results=results)

#------------------------------------------------------------------------------------------------------------
#Test search features based on app design
#--------------------------------------------------------------------------------------------------------------
#@app.route('/search', methods=['GET', 'POST'])
#def search():
    #searched=[]
    #form =SearchForm()
    #if form.validate_on_submit():
        #Flights = Flight.query.filter_by(flight_id=form.flight_id.data).first()
        #if Flights is None:
            #pass
        #searched = form.searched.data
        #form.searched.data = ''
        #flash("You are successfully registered")
        #our_search = Flight.query.order_by(Flight.flight_id)
        #return render_template("search.html", form=form, searched=searched)#, our_search=our_search)#searched=searched